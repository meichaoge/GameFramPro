﻿
/// <summary>
/// Used for action do over callbacks
/// </summary>
public delegate void ActionCallback();
/// <summary>
/// Used for action do over callbacks
/// </summary>
public delegate void ActionCallback<in T>(T value);